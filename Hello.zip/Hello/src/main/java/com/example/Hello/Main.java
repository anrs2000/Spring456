package com.example.Hello;

import com.example.Hello.Objetos.Laptop;
import com.example.Hello.Repositorios.LaptopRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Main {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Main.class, args);
		LaptopRepository repository = context.getBean(LaptopRepository.class);

		//Insertamos (creamos y guardamos) objetos desde el Main
		Laptop laptop1 = new Laptop("lenovo", null, 1000);
		repository.save(laptop1);

		Laptop laptop2 = new Laptop("apple", null, 1900);
		repository.save(laptop2);

		Laptop laptop3 = new Laptop("HP", null, 3000);
		repository.save(laptop3);

	}
}
