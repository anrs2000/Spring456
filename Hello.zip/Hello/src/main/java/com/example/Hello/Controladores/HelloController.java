package com.example.Hello.Controladores;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
//Método que devuelva un saludo

    @GetMapping("/saludo")
    public String saludo(){
        return "Hola!!";
    }
}
