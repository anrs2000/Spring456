package com.example.Hello.Objetos;

import com.example.Hello.Repositorios.LaptopRepository;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class Laptop {
    //Atributos
    private String marca;
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;
    private int battery;

    //Constructores

    public Laptop() {
    }
@Autowired
    public Laptop(String marca, Long id, int battery) {
        this.marca = marca;
        this.id = id;
        this.battery = battery;
    }

    //Getter y setter

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }
}
