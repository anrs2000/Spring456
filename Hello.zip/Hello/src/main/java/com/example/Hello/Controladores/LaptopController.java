package com.example.Hello.Controladores;
import com.example.Hello.Repositorios.LaptopRepository;
import org.springframework.web.bind.annotation.*;
import com.example.Hello.Objetos.Laptop;
import java.util.List;
import java.util.Optional;


@RestController
public class LaptopController {
    /* Debemos pasar una instancia válida del repositorio al controlador:
    1. Atributo de tipo LaptopRepository (repositorio)
    2. Constructor de LaptopController que contenga ese atributo
     */
    private LaptopRepository repositorio;
    public LaptopController(LaptopRepository repositorio) {
        this.repositorio = repositorio;

    }
    //CREAR Y GUARDAR OBJETOS
    // ~Método para crear y guardar objetos desde una solicitud HTTP POST
    @PostMapping("/create/laptop")
    public Laptop create(@RequestBody Laptop laptop) {
        return repositorio.save(laptop);
    }



    //DEVOLVER LOS LAPTOPS

    //Crear un método que devuelva una lista de objetos Laptop
    @GetMapping("/findAllLaptops")
    public List<Laptop> findAllLaptops(){
        return repositorio.findAll();
    }

    //Devolver los objetos Laptop por el Id
    @GetMapping("/findAllLaptops/{id}")
    public Laptop findByID(@PathVariable Long id){
        Optional<Laptop> laptopOptional = repositorio.findById(id);
        return laptopOptional.orElse(null);
    }


}